﻿using System;

Console.WriteLine("File-scoped Types");
